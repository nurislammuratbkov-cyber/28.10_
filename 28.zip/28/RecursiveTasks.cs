using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Numerics;
using System.Text;

public static class RecursiveTasks
{
    // Задание 1. Вывод чисел от 1 до N.
    public static void PrintAscending(int n)
    {
        if (n < 1)
            return;

        PrintAscending(n - 1);
        Console.WriteLine(n);
    }

    // Задание 2. Вывод чисел от N до 1.
    public static void PrintDescending(int n)
    {
        if (n < 1)
            return;

        Console.WriteLine(n);
        PrintDescending(n - 1);
    }

    // Задание 3. Сумма натуральных чисел от 1 до N.
    public static long SumToN(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "N не может быть отрицательным.");

        return n == 0 ? 0 : checked(n + SumToN(n - 1));
    }

    // Задание 4. Факториал N.
    public static long Factorial(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "N не может быть отрицательным.");

        return n <= 1 ? 1 : checked(n * Factorial(n - 1));
    }

    // Задание 5. Возведение a в степень n обычной рекурсией.
    public static long Power(int a, int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Степень должна быть неотрицательной.");

        return n == 0 ? 1 : checked(a * Power(a, n - 1));
    }

    // Задание 6. Сумма цифр неотрицательного числа.
    public static int SumOfDigits(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Число должно быть неотрицательным.");

        return n == 0 ? 0 : n % 10 + SumOfDigits(n / 10);
    }

    // Задание 7. Количество цифр в неотрицательном числе.
    public static int CountDigits(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Число должно быть неотрицательным.");

        return n < 10 ? 1 : 1 + CountDigits(n / 10);
    }

    // Задание 8. Произведение цифр числа.
    public static int ProductOfDigits(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Число должно быть неотрицательным.");

        return n < 10 ? n : n % 10 * ProductOfDigits(n / 10);
    }

    // Задание 9. Максимальная цифра натурального числа.
    public static int MaxDigit(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Число должно быть неотрицательным.");

        return n < 10 ? n : Math.Max(n % 10, MaxDigit(n / 10));
    }

    // Задание 10. Минимальная цифра числа.
    public static int MinDigit(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Число должно быть неотрицательным.");

        return n < 10 ? n : Math.Min(n % 10, MinDigit(n / 10));
    }

    // Задание 11. N-е число Фибоначчи (F(0) = 0, F(1) = 1).
    public static long Fibonacci(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Индекс не может быть отрицательным.");

        if (n <= 1)
            return n;

        return checked(Fibonacci(n - 1) + Fibonacci(n - 2));
    }

    // Задание 12. Сумма элементов массива, начиная с указанного индекса.
    public static long ArraySum(int[] array, int index = 0)
    {
        if (array == null)
            throw new ArgumentNullException(nameof(array));
        if (index < 0 || index > array.Length)
            throw new ArgumentOutOfRangeException(nameof(index));

        return index == array.Length
            ? 0
            : checked(array[index] + ArraySum(array, index + 1));
    }

    // Задание 13. Максимальный элемент массива.
    public static int ArrayMax(int[] array)
    {
        ValidateNonEmptyArray(array);
        return ArrayMax(array, 0);
    }

    private static int ArrayMax(int[] array, int index)
    {
        return index == array.Length - 1
            ? array[index]
            : Math.Max(array[index], ArrayMax(array, index + 1));
    }

    // Задание 14. Минимальный элемент массива.
    public static int ArrayMin(int[] array)
    {
        ValidateNonEmptyArray(array);
        return ArrayMin(array, 0);
    }

    private static int ArrayMin(int[] array, int index)
    {
        return index == array.Length - 1
            ? array[index]
            : Math.Min(array[index], ArrayMin(array, index + 1));
    }

    // Задание 15. Количество чётных элементов массива.
    public static int CountEven(int[] array, int index = 0)
    {
        if (array == null)
            throw new ArgumentNullException(nameof(array));
        if (index < 0 || index > array.Length)
            throw new ArgumentOutOfRangeException(nameof(index));

        if (index == array.Length)
            return 0;

        return (array[index] % 2 == 0 ? 1 : 0) + CountEven(array, index + 1);
    }

    // Задание 16. Проверка сортировки массива по неубыванию.
    public static bool IsSortedAscending(int[] array)
    {
        if (array == null)
            throw new ArgumentNullException(nameof(array));

        return IsSortedAscending(array, 0);
    }

    private static bool IsSortedAscending(int[] array, int index)
    {
        return index >= array.Length - 1
            || (array[index] <= array[index + 1] && IsSortedAscending(array, index + 1));
    }

    // Задание 17. НОД алгоритмом Евклида.
    public static long Gcd(int a, int b)
    {
        return Gcd(Math.Abs((long)a), Math.Abs((long)b));
    }

    private static long Gcd(long a, long b)
    {
        return b == 0 ? a : Gcd(b, a % b);
    }

    // Задание 18. НОК положительных чисел; НОД вычисляется отдельным методом.
    public static long Lcm(int a, int b)
    {
        if (a <= 0)
            throw new ArgumentOutOfRangeException(nameof(a), "Число должно быть положительным.");
        if (b <= 0)
            throw new ArgumentOutOfRangeException(nameof(b), "Число должно быть положительным.");

        return checked((long)a / Gcd(a, b) * b);
    }

    // Задание 19. Двоичное представление положительного числа.
    public static string ToBinary(int n)
    {
        if (n <= 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Число должно быть положительным.");

        return n < 2 ? n.ToString(CultureInfo.InvariantCulture) : ToBinary(n / 2) + (n % 2);
    }

    public static void PrintBinary(int n)
    {
        Console.WriteLine(ToBinary(n));
    }

    // Задание 20. Сумма квадратов чисел от 1 до N.
    public static long SumOfSquares(int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "N не может быть отрицательным.");

        return n == 0 ? 0 : checked((long)n * n + SumOfSquares(n - 1));
    }

    // Задание 21. Переворот строки.
    public static string ReverseString(string text)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        return ReverseString(text, 0);
    }

    private static string ReverseString(string text, int index)
    {
        return index == text.Length ? string.Empty : ReverseString(text, index + 1) + text[index];
    }

    // Задание 22. Проверка строки на палиндром.
    public static bool IsPalindrome(string text)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        return IsPalindrome(text, 0, text.Length - 1);
    }

    private static bool IsPalindrome(string text, int left, int right)
    {
        return left >= right
            || (text[left] == text[right] && IsPalindrome(text, left + 1, right - 1));
    }

    // Задание 23. Количество вхождений символа в строку.
    public static int CountCharacter(string text, char character)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        return CountCharacter(text, character, 0);
    }

    private static int CountCharacter(string text, char character, int index)
    {
        if (index == text.Length)
            return 0;

        return (text[index] == character ? 1 : 0) + CountCharacter(text, character, index + 1);
    }

    // Задание 24. Подсчёт английских и русских гласных.
    public static int CountVowels(string text)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        return CountVowels(text, 0);
    }

    private static int CountVowels(string text, int index)
    {
        if (index == text.Length)
            return 0;

        char character = char.ToLowerInvariant(text[index]);
        bool isVowel = "aeiouаеёиоуыэюя".IndexOf(character) >= 0;
        return (isVowel ? 1 : 0) + CountVowels(text, index + 1);
    }

    // Задание 25. Удаление всех вхождений символа из строки.
    public static string RemoveCharacter(string text, char character)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        StringBuilder result = new StringBuilder();
        RemoveCharacter(text, character, 0, result);
        return result.ToString();
    }

    private static void RemoveCharacter(string text, char character, int index, StringBuilder result)
    {
        if (index == text.Length)
            return;

        if (text[index] != character)
            result.Append(text[index]);

        RemoveCharacter(text, character, index + 1, result);
    }

    // Задание 26. Замена всех вхождений одного символа другим.
    public static string ReplaceCharacter(string text, char oldCharacter, char newCharacter)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        StringBuilder result = new StringBuilder();
        ReplaceCharacter(text, oldCharacter, newCharacter, 0, result);
        return result.ToString();
    }

    private static void ReplaceCharacter(
        string text, char oldCharacter, char newCharacter, int index, StringBuilder result)
    {
        if (index == text.Length)
            return;

        result.Append(text[index] == oldCharacter ? newCharacter : text[index]);
        ReplaceCharacter(text, oldCharacter, newCharacter, index + 1, result);
    }

    // Задание 27. Проверка, что все символы строки одинаковы.
    public static bool HasOnlySameCharacters(string text)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        return text.Length < 2 || HasOnlySameCharacters(text, text[0], 1);
    }

    private static bool HasOnlySameCharacters(string text, char expected, int index)
    {
        return index == text.Length
            || (text[index] == expected && HasOnlySameCharacters(text, expected, index + 1));
    }

    // Задание 28. Подсчёт слов, разделённых пробелами.
    public static int CountWords(string text)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        return CountWords(text, 0, false);
    }

    private static int CountWords(string text, int index, bool insideWord)
    {
        if (index == text.Length)
            return 0;

        bool isSpace = text[index] == ' ';
        int startsWord = !isSpace && !insideWord ? 1 : 0;
        return startsWord + CountWords(text, index + 1, !isSpace);
    }

    // Задание 29. Проверка анаграммы через рекурсивный подсчёт частот символов.
    public static bool AreAnagrams(string first, string second)
    {
        if (first == null)
            throw new ArgumentNullException(nameof(first));
        if (second == null)
            throw new ArgumentNullException(nameof(second));
        if (first.Length != second.Length)
            return false;

        Dictionary<char, int> firstCounts = new Dictionary<char, int>();
        Dictionary<char, int> secondCounts = new Dictionary<char, int>();
        CountFrequencies(first, 0, firstCounts);
        CountFrequencies(second, 0, secondCounts);

        if (firstCounts.Count != secondCounts.Count)
            return false;

        char[] keys = firstCounts.Keys.ToArray();
        return FrequenciesMatch(firstCounts, secondCounts, keys, 0);
    }

    private static void CountFrequencies(string text, int index, Dictionary<char, int> counts)
    {
        if (index == text.Length)
            return;

        char character = text[index];
        counts[character] = counts.TryGetValue(character, out int count) ? count + 1 : 1;
        CountFrequencies(text, index + 1, counts);
    }

    private static bool FrequenciesMatch(
        Dictionary<char, int> first, Dictionary<char, int> second, char[] keys, int index)
    {
        if (index == keys.Length)
            return true;

        char key = keys[index];
        return second.TryGetValue(key, out int count)
            && count == first[key]
            && FrequenciesMatch(first, second, keys, index + 1);
    }

    // Задание 30. Рекурсивное посимвольное сравнение строк.
    public static int CompareStrings(string first, string second)
    {
        if (first == null)
            throw new ArgumentNullException(nameof(first));
        if (second == null)
            throw new ArgumentNullException(nameof(second));

        return CompareStrings(first, second, 0);
    }

    private static int CompareStrings(string first, string second, int index)
    {
        if (index == first.Length || index == second.Length)
            return first.Length.CompareTo(second.Length);
        if (first[index] != second[index])
            return first[index] < second[index] ? -1 : 1;

        return CompareStrings(first, second, index + 1);
    }

    // Задание 31. Быстрое рекурсивное возведение в степень за O(log n).
    public static long FastPower(long a, int n)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Степень должна быть неотрицательной.");
        if (n == 0)
            return 1;

        long half = FastPower(a, n / 2);
        long square = checked(half * half);
        return n % 2 == 0 ? square : checked(square * a);
    }

    // Задание 32. Рекурсивный бинарный поиск; возвращает индекс или -1.
    public static int BinarySearch(int[] sortedArray, int value)
    {
        if (sortedArray == null)
            throw new ArgumentNullException(nameof(sortedArray));

        return BinarySearch(sortedArray, value, 0, sortedArray.Length - 1);
    }

    private static int BinarySearch(int[] array, int value, int left, int right)
    {
        if (left > right)
            return -1;

        int middle = left + (right - left) / 2;
        if (array[middle] == value)
            return middle;

        return array[middle] > value
            ? BinarySearch(array, value, left, middle - 1)
            : BinarySearch(array, value, middle + 1, right);
    }

    // Задание 33. Сортировка слиянием.
    public static void MergeSort(int[] array)
    {
        if (array == null)
            throw new ArgumentNullException(nameof(array));
        MergeSort(array, new int[array.Length], 0, array.Length - 1);
    }

    private static void MergeSort(int[] array, int[] buffer, int left, int right)
    {
        if (left >= right)
            return;

        int middle = left + (right - left) / 2;
        MergeSort(array, buffer, left, middle);
        MergeSort(array, buffer, middle + 1, right);
        Merge(array, buffer, left, middle, right);
    }

    private static void Merge(int[] array, int[] buffer, int left, int middle, int right)
    {
        int first = left;
        int second = middle + 1;
        int destination = left;

        while (first <= middle && second <= right)
            buffer[destination++] = array[first] <= array[second] ? array[first++] : array[second++];
        while (first <= middle)
            buffer[destination++] = array[first++];
        while (second <= right)
            buffer[destination++] = array[second++];
        for (int i = left; i <= right; i++)
            array[i] = buffer[i];
    }

    // Задание 34. Быстрая сортировка (Quick Sort).
    public static void QuickSort(int[] array)
    {
        if (array == null)
            throw new ArgumentNullException(nameof(array));
        QuickSort(array, 0, array.Length - 1);
    }

    private static void QuickSort(int[] array, int left, int right)
    {
        if (left >= right)
            return;

        int pivot = array[left + (right - left) / 2];
        int i = left;
        int j = right;
        while (i <= j)
        {
            while (array[i] < pivot)
                i++;
            while (array[j] > pivot)
                j--;
            if (i <= j)
            {
                int temporary = array[i];
                array[i] = array[j];
                array[j] = temporary;
                i++;
                j--;
            }
        }

        if (left < j)
            QuickSort(array, left, j);
        if (i < right)
            QuickSort(array, i, right);
    }

    // Задание 35. Ханойская башня: печать перемещений дисков.
    public static void TowerOfHanoi(int n, string source, string destination, string auxiliary)
    {
        if (n < 0)
            throw new ArgumentOutOfRangeException(nameof(n), "Количество дисков не может быть отрицательным.");
        if (source == null)
            throw new ArgumentNullException(nameof(source));
        if (destination == null)
            throw new ArgumentNullException(nameof(destination));
        if (auxiliary == null)
            throw new ArgumentNullException(nameof(auxiliary));

        if (n == 0)
            return;

        TowerOfHanoi(n - 1, source, auxiliary, destination);
        Console.WriteLine("{0} -> {1}", source, destination);
        TowerOfHanoi(n - 1, auxiliary, destination, source);
    }

    // Задание 36. Печать всех подмножеств массива.
    public static void PrintSubsets(int[] array)
    {
        if (array == null)
            throw new ArgumentNullException(nameof(array));

        PrintSubsets(array, 0, new List<int>());
    }

    private static void PrintSubsets(int[] array, int index, List<int> current)
    {
        if (index == array.Length)
        {
            Console.WriteLine("[" + string.Join(", ", current) + "]");
            return;
        }

        PrintSubsets(array, index + 1, current);
        current.Add(array[index]);
        PrintSubsets(array, index + 1, current);
        current.RemoveAt(current.Count - 1);
    }

    // Задание 37. Печать всех уникальных перестановок строки.
    public static void PrintUniquePermutations(string text)
    {
        if (text == null)
            throw new ArgumentNullException(nameof(text));

        char[] characters = text.ToCharArray();
        Array.Sort(characters);
        PrintUniquePermutations(characters, new bool[characters.Length], new StringBuilder(), 0);
    }

    private static void PrintUniquePermutations(
        char[] characters, bool[] used, StringBuilder current, int depth)
    {
        if (depth == characters.Length)
        {
            Console.WriteLine(current.ToString());
            return;
        }

        for (int i = 0; i < characters.Length; i++)
        {
            if (used[i] || (i > 0 && characters[i] == characters[i - 1] && !used[i - 1]))
                continue;

            used[i] = true;
            current.Append(characters[i]);
            PrintUniquePermutations(characters, used, current, depth + 1);
            current.Length--;
            used[i] = false;
        }
    }

    // Задание 38. Поиск одного пути в лабиринте (0 — проход, 1 — стена).
    public static bool FindMazePath(
        int[,] maze, int startRow, int startColumn, int endRow, int endColumn,
        out List<(int Row, int Column)> path)
    {
        if (maze == null)
            throw new ArgumentNullException(nameof(maze));

        path = new List<(int Row, int Column)>();
        int rows = maze.GetLength(0);
        int columns = maze.GetLength(1);
        if (!IsInsideMaze(startRow, startColumn, rows, columns)
            || !IsInsideMaze(endRow, endColumn, rows, columns)
            || maze[startRow, startColumn] != 0
            || maze[endRow, endColumn] != 0)
            return false;

        bool[,] visited = new bool[rows, columns];
        return FindMazePath(maze, startRow, startColumn, endRow, endColumn, visited, path);
    }

    private static bool FindMazePath(
        int[,] maze, int row, int column, int endRow, int endColumn,
        bool[,] visited, List<(int Row, int Column)> path)
    {
        if (!IsInsideMaze(row, column, maze.GetLength(0), maze.GetLength(1))
            || maze[row, column] != 0
            || visited[row, column])
            return false;

        visited[row, column] = true;
        path.Add((row, column));
        if (row == endRow && column == endColumn)
            return true;

        if (FindMazePath(maze, row - 1, column, endRow, endColumn, visited, path)
            || FindMazePath(maze, row + 1, column, endRow, endColumn, visited, path)
            || FindMazePath(maze, row, column - 1, endRow, endColumn, visited, path)
            || FindMazePath(maze, row, column + 1, endRow, endColumn, visited, path))
            return true;

        path.RemoveAt(path.Count - 1);
        return false;
    }

    private static bool IsInsideMaze(int row, int column, int rows, int columns)
    {
        return row >= 0 && row < rows && column >= 0 && column < columns;
    }

    // Задание 39. Поиск и печать всех решений задачи о N ферзях.
    public static List<int[]> SolveNQueens(int n)
    {
        if (n < 1)
            throw new ArgumentOutOfRangeException(nameof(n), "Размер доски должен быть положительным.");

        List<int[]> solutions = new List<int[]>();
        int[] queenColumns = new int[n];
        PlaceQueens(0, queenColumns, solutions);
        return solutions;
    }

    public static void PrintNQueensSolutions(int n)
    {
        List<int[]> solutions = SolveNQueens(n);
        foreach (int[] solution in solutions)
        {
            for (int row = 0; row < n; row++)
            {
                for (int column = 0; column < n; column++)
                    Console.Write(solution[row] == column ? "Q " : ". ");
                Console.WriteLine();
            }
            Console.WriteLine();
        }
    }

    private static void PlaceQueens(int row, int[] queenColumns, List<int[]> solutions)
    {
        if (row == queenColumns.Length)
        {
            solutions.Add((int[])queenColumns.Clone());
            return;
        }

        for (int column = 0; column < queenColumns.Length; column++)
        {
            if (!IsQueenPositionSafe(row, column, queenColumns))
                continue;

            queenColumns[row] = column;
            PlaceQueens(row + 1, queenColumns, solutions);
        }
    }

    private static bool IsQueenPositionSafe(int row, int column, int[] queenColumns)
    {
        for (int previousRow = 0; previousRow < row; previousRow++)
        {
            int previousColumn = queenColumns[previousRow];
            if (previousColumn == column
                || Math.Abs(previousColumn - column) == Math.Abs(previousRow - row))
                return false;
        }

        return true;
    }

    // Задание 40. Генерация выражений с +, - и * и стандартным приоритетом операций.
    public static List<string> ExpressionsForTarget(string digits, long target)
    {
        if (digits == null)
            throw new ArgumentNullException(nameof(digits));
        for (int i = 0; i < digits.Length; i++)
        {
            if (digits[i] < '0' || digits[i] > '9')
                throw new ArgumentException("Строка должна содержать только цифры.", nameof(digits));
        }

        List<string> expressions = new List<string>();
        if (digits.Length == 0)
            return expressions;

        BuildExpressions(
            digits, 0, BigInteger.Zero, BigInteger.Zero, string.Empty,
            new BigInteger(target), expressions);
        return expressions;
    }

    private static void BuildExpressions(
        string digits, int position, BigInteger total, BigInteger lastTerm,
        string expression, BigInteger target, List<string> results)
    {
        if (position == digits.Length)
        {
            if (total == target)
                results.Add(expression);
            return;
        }

        for (int end = position + 1; end <= digits.Length; end++)
        {
            if (end > position + 1 && digits[position] == '0')
                break;

            BigInteger operand = BigInteger.Parse(
                digits.Substring(position, end - position), CultureInfo.InvariantCulture);
            string operandText = digits.Substring(position, end - position);

            if (position == 0)
            {
                BuildExpressions(digits, end, operand, operand, operandText, target, results);
                continue;
            }

            BuildExpressions(
                digits, end, total + operand, operand,
                expression + "+" + operandText, target, results);
            BuildExpressions(
                digits, end, total - operand, -operand,
                expression + "-" + operandText, target, results);
            BuildExpressions(
                digits, end, total - lastTerm + lastTerm * operand, lastTerm * operand,
                expression + "*" + operandText, target, results);
        }
    }

    private static void ValidateNonEmptyArray(int[] array)
    {
        if (array == null)
            throw new ArgumentNullException(nameof(array));
        if (array.Length == 0)
            throw new ArgumentException("Массив не должен быть пустым.", nameof(array));
    }
}
