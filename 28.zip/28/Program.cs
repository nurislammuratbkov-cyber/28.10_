using System;
using System.Linq;

Console.WriteLine("1. Числа от 1 до 5:");
RecursiveTasks.PrintAscending(5);

Console.WriteLine("\n2. Числа от 5 до 1:");
RecursiveTasks.PrintDescending(5);

Console.WriteLine("\n3. Сумма чисел от 1 до 5: " + RecursiveTasks.SumToN(5));
Console.WriteLine("4. Факториал числа 5: " + RecursiveTasks.Factorial(5));
Console.WriteLine("5. 2 в степени 5: " + RecursiveTasks.Power(2, 5));
Console.WriteLine("6. Сумма цифр числа 583: " + RecursiveTasks.SumOfDigits(583));
Console.WriteLine("7. Количество цифр в числе 583: " + RecursiveTasks.CountDigits(583));
Console.WriteLine("8. Произведение цифр числа 234: " + RecursiveTasks.ProductOfDigits(234));
Console.WriteLine("9. Максимальная цифра числа 583: " + RecursiveTasks.MaxDigit(583));
Console.WriteLine("10. Минимальная цифра числа 583: " + RecursiveTasks.MinDigit(583));
Console.WriteLine("11. Число Фибоначчи F(10): " + RecursiveTasks.Fibonacci(10));

int[] numbers = { 4, 2, 7, 1, 6 };
Console.WriteLine("\n12. Сумма элементов массива [4, 2, 7, 1, 6]: " + RecursiveTasks.ArraySum(numbers));
Console.WriteLine("13. Максимум массива: " + RecursiveTasks.ArrayMax(numbers));
Console.WriteLine("14. Минимум массива: " + RecursiveTasks.ArrayMin(numbers));
Console.WriteLine("15. Количество чётных элементов массива: " + RecursiveTasks.CountEven(numbers));
Console.WriteLine("16. Массив [1, 2, 3, 4] отсортирован по возрастанию: "
    + RecursiveTasks.IsSortedAscending(new[] { 1, 2, 3, 4 }));
Console.WriteLine("17. НОД чисел 48 и 18: " + RecursiveTasks.Gcd(48, 18));
Console.WriteLine("18. НОК чисел 12 и 18: " + RecursiveTasks.Lcm(12, 18));
Console.WriteLine("19. Число 25 в двоичной системе: " + RecursiveTasks.ToBinary(25));
Console.WriteLine("20. Сумма квадратов от 1 до 5: " + RecursiveTasks.SumOfSquares(5));

Console.WriteLine("\n21. Перевёрнутая строка Java: " + RecursiveTasks.ReverseString("Java"));
Console.WriteLine("22. Строка «казак» — палиндром: " + RecursiveTasks.IsPalindrome("казак"));
Console.WriteLine("23. Количество букв «а» в слове «банан»: "
    + RecursiveTasks.CountCharacter("банан", 'а'));
Console.WriteLine("24. Количество гласных в строке «Привет, World»: "
    + RecursiveTasks.CountVowels("Привет, World"));
Console.WriteLine("25. Удаление буквы «а» из слова «банан»: "
    + RecursiveTasks.RemoveCharacter("банан", 'а'));
Console.WriteLine("26. Замена букв «а» на «о» в слове «банан»: "
    + RecursiveTasks.ReplaceCharacter("банан", 'а', 'о'));
Console.WriteLine("27. Строка «aaaaa» состоит из одинаковых символов: "
    + RecursiveTasks.HasOnlySameCharacters("aaaaa"));
Console.WriteLine("28. Количество слов в строке «один два три»: "
    + RecursiveTasks.CountWords("один два три"));
Console.WriteLine("29. Строки «listen» и «silent» — анаграммы: "
    + RecursiveTasks.AreAnagrams("listen", "silent"));
Console.WriteLine("30. Сравнение строк «abc» и «abd»: "
    + RecursiveTasks.CompareStrings("abc", "abd"));
Console.WriteLine("31. Быстрое возведение 2 в степень 10: "
    + RecursiveTasks.FastPower(2, 10));
Console.WriteLine("32. Индекс числа 7 в массиве [1, 3, 5, 7, 9]: "
    + RecursiveTasks.BinarySearch(new[] { 1, 3, 5, 7, 9 }, 7));

int[] mergeSortArray = { 5, 2, 8, 1, 3 };
RecursiveTasks.MergeSort(mergeSortArray);
Console.WriteLine("33. Сортировка слиянием: [" + string.Join(", ", mergeSortArray) + "]");

int[] quickSortArray = { 9, 4, 6, 2, 7 };
RecursiveTasks.QuickSort(quickSortArray);
Console.WriteLine("34. Быстрая сортировка: [" + string.Join(", ", quickSortArray) + "]");

Console.WriteLine("\n35. Ханойская башня для 3 дисков:");
RecursiveTasks.TowerOfHanoi(3, "A", "C", "B");

Console.WriteLine("\n36. Все подмножества массива [1, 2]:");
RecursiveTasks.PrintSubsets(new[] { 1, 2 });

Console.WriteLine("\n37. Все перестановки строки ABC:");
RecursiveTasks.PrintUniquePermutations("ABC");

int[,] maze =
{
    { 0, 0, 1, 0 },
    { 1, 0, 1, 0 },
    { 0, 0, 0, 0 },
    { 0, 1, 1, 0 }
};
bool mazeHasPath = RecursiveTasks.FindMazePath(maze, 0, 0, 3, 3, out var mazePath);
Console.WriteLine("\n38. Путь в лабиринте найден: " + mazeHasPath);
if (mazeHasPath)
{
    Console.WriteLine(string.Join(" -> ", mazePath.Select(cell => $"({cell.Row}, {cell.Column})")));
}

Console.WriteLine("\n39. Все решения задачи о 4 ферзях:");
RecursiveTasks.PrintNQueensSolutions(4);

Console.WriteLine("40. Выражения из цифр 123 со значением 6:");
Console.WriteLine(string.Join(", ", RecursiveTasks.ExpressionsForTarget("123", 6)));
